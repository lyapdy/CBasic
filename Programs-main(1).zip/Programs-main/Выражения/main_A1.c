#include <stdio.h>

int main () {
    printf("	 Let's\n           go\n               to walk\n");
    return 0;
}