#include <stdio.h>

int main () {
    printf("     *\n    ***\n   *****\n  *******\n   HHOHH\n   ZZZZZ");
    return 0;
}