#include <stdio.h>

int main () {
    int a, b, sub; 
    scanf("%d%d", &a, &b);
    sub = a - b;
    printf("%d", sub);
    return 0;
}